export const TOKEN_SECRET = "Clave Secreta"
export const FRONT_END_URL= process.env.FRONT_END_URL || 'http://localhost:5173'